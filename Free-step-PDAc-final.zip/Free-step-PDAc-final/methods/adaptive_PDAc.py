from __future__ import division
import numpy as np
import numpy.linalg as LA
from itertools import count
from time import time
import scipy.linalg as scp_LA


"""
Step-free PDA with convex combination proposed by Xiaokai Chang and Xulong
involving adaptive step tau and sigma
"""


def pd_free_PDAc_adaptive_LASSO(J, prox_g, prox_f_conj, dis_sub, K, x0, y0, sigma, tau, phi, min_val,la, b, numb_iter=100, tol=1e-12):
    """
    The step-free Primal-dual algorithm for the problem min_x max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    w_old = K.dot(x0)
    x, y, u = x0, y0, x0
    Kty = K.T.dot(y0)
    m,n = K.shape
    eta = phi*(2+2*phi-phi**2)/(1+phi)
    print(eta)
 
    I1 = np.eye(m)
    M = (sigma*tau) / eta * np.dot(K, K.T) + (1+0.001) * I1
    L = LA.cholesky(M)
    
    values = [J(x0, y0, min_val)]
    tt = [0]  
    pd_inf = []
    
    # for adaptive step 
    it_pinf = 0
    it_dinf = 0
    xi = 0.9
    MUmin = 1e-6
    MUmax = 1e+6
    
    begin = time()
    for i in range(numb_iter):
        # compute x
        u = x - (1/phi)*(x - u)
        x = prox_g(u - tau * Kty, tau)
        Kx = K.dot(x)
            
        # compute w
        y_ = prox_f_conj(sigma*w_old + y, sigma)
        w = w_old + 1/sigma * (y - y_)
            
        # compute y
        h_hat = Kx-(2*w-w_old)
        # print(np.isinf(L).any(),np.isinf(y_hat).any)
        z = scp_LA.solve_triangular(L, h_hat, lower=True)
        # print(np.isinf(y1).any())
        h = scp_LA.solve_triangular(L.T, z, lower=False)
        y1 = y + sigma * h
        Kty1 = K.T.dot(y1)
              
        p_inf = LA.norm(Kx - w,1)
        d_inf = dis_sub(la, x, Kty) + LA.norm(w-b-y,1)
        #d_inf = LA.norm((u-x)/tau +Kty1-Kty,1)+LA.norm(w-b-y,1)
        #d_inf = LA.norm((u-x)/tau +Kty1-Kty,1)+LA.norm(y1-y+sigma*(w-w_old),1)
        dtmp = p_inf/d_inf
        max_inf = max(p_inf, d_inf)
        
        ## updating sigma and tau adaptively
        if i <= 21:
             hh =3
        elif i <= 61:
            hh =6
        elif i <= 121:
            hh =50
        else:
            hh = 100
         
        if dtmp <= 1/1.2:
            it_pinf = it_pinf+1
            it_dinf = 0
            if it_pinf > hh and tau/sigma<10:
                tau = min(1/xi *tau, MUmax)
                sigma = max(xi *sigma, MUmin)
                it_pinf=0
                
        elif dtmp >= 1.2:
            it_dinf = it_dinf+1; 
            it_pinf = 0;
            if it_dinf > hh and tau/sigma>1/10:
                tau = max(xi *tau,MUmin)
                sigma = min(1/xi *sigma,MUmax) 
                it_dinf = 0;
        
        values.append(J(x, y_, min_val)) 
        tt.append(time() - begin)
        pd_inf.append(max_inf) 
        
        if values[-1] <= tol:
            end = time()
            print ("----- Adaptive Stepfree PDA-----")
            print ("Time execution:", round(end - begin,2))
            print("iteration:")
            print(len(tt)-1)
            return [values,pd_inf, x, y,tt]
        else:
            y, Kty, w_old =y1, Kty1, w
                   
            
    end = time()
    print ("----- Adaptive  Stepfree PDA-----")
    print ("Time execution:", round(end - begin,2))
    print("iteration:")
    print(len(tt)-1)
    return [values, pd_inf, x, y,tt]


def pd_free_PDAc_adaptive_MMG(J, prox_g, prox_f_conj, K, x0, y0, sigma, tau, phi, min_val, numb_iter=100, tol=1e-12):
    """
    The step-free Primal-dual algorithm for the problem min_x max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    w_old = K.dot(x0)
    x, y, u = x0, y0, x0
    Kty = K.T.dot(y0)
    m,n = K.shape
    eta = phi*(2+2*phi-phi**2)/(1+phi)
    print(eta)
 
    I1 = np.eye(m)
    M = (sigma*tau) / eta * np.dot(K, K.T) + (1+0.001) * I1
    L = LA.cholesky(M)
    
    values = [J(x0, y0, min_val)]
    tt = [0]  
    pd_inf = []
    
    # for adaptive step 
    it_pinf = 0
    it_dinf = 0
    xi = 0.9
    adap = 1
    MUmin = 1e-6
    MUmax = 1e+6
    c_pd = []
    
    begin = time()
    for i in range(numb_iter):
        # compute x
        u = x - (1/phi)*(x - u)
        x = prox_g(u - tau * Kty, tau)
        Kx = K.dot(x)
            
        # compute w
        y_ = prox_f_conj(sigma*w_old + y, sigma)
        w = w_old + 1/sigma * (y - y_)
            
        # compute y
        h_hat = Kx-(2*w-w_old)
        # print(np.isinf(L).any(),np.isinf(y_hat).any)
        z = scp_LA.solve_triangular(L, h_hat, lower=True)
        # print(np.isinf(y1).any())
        h = scp_LA.solve_triangular(L.T, z, lower=False)
        y1 = y + sigma * h
        Kty1 = K.T.dot(y1)
              
        p_inf = LA.norm(Kx - w,1)
        d_inf = LA.norm((u-x)/tau +Kty1-Kty,1)+ LA.norm(y1-y+sigma*(w-w_old),1)
        dtmp = p_inf/d_inf
        max_inf = max(p_inf, d_inf)
        #print(max_inf)
        
        ## updating sigma and tau adaptively
        if adap == 1:
            if i <= 21:
                 hh =3
            elif i <= 61:
                hh =6
            elif i <= 121:
                hh =50
            else:
                hh = 100
         
            if dtmp <= 1/1.5:
                it_pinf = it_pinf+1
                it_dinf = 0
                if it_pinf > hh:
                    tau = min(1/xi *tau, MUmax)
                    sigma = max(xi *sigma, MUmin)
                    it_pinf=0
                    print(tau/sigma)
                    c_pd.append(1)
                        
                
            elif dtmp >= 1.5:
                it_dinf = it_dinf+1; 
                it_pinf = 0;
                if it_dinf > hh:
                    tau = max(xi *tau,MUmin)
                    sigma = min(1/xi *sigma,MUmax) 
                    it_dinf = 0
                    print(tau/sigma)
                    c_pd.append(0)
                
            if len(c_pd)>5 and c_pd[-5:-1:1]==[1,0,1,0]:
                xi = 1
                adap = 0
            
        #values.append(J(x, y_, min_val)) 
        values.append(max_inf) 
        tt.append(time() - begin)
        pd_inf.append(max_inf) 
        
        #if values[-1] <= tol:
        if max_inf <= tol:
            end = time()
            print ("----- Adaptive Stepfree PDA-----")
            print ("Time execution:", round(end - begin,2))
            print("iteration:")
            print(len(tt)-1)
            return [values,pd_inf, x, y,tt]
        else:
            y, Kty, w_old =y1, Kty1, w
                   
            
    end = time()
    print ("----- Adaptive  Stepfree PDA-----")
    print ("Time execution:", round(end - begin,2))
    print("iteration:")
    print(len(tt)-1)
    return [values, pd_inf, x, y,tt]


